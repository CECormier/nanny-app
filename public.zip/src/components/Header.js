
function Header()
{
    return(
        <header>
            <div id="header">
                <div>
                <img src="/Photos/nannylogo3.png" alt="Logo"></img>

                </div>
            </div>
        </header>
    )
}

export default Header;