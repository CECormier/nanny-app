import Home from './User/Home'

function Dashboard()
{
    return(
        <main>
           <Home/>
           <h1>Available Jobs</h1>
     
        </main>
    )
}


export default Dashboard;